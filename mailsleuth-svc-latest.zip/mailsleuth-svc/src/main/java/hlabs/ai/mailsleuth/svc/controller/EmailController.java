package hlabs.ai.mailsleuth.svc.controller;

import hlabs.ai.mailsleuth.svc.dto.EmailCountDTO;
import hlabs.ai.mailsleuth.svc.models.Email;
import hlabs.ai.mailsleuth.svc.service.EmailService;
import lombok.RequiredArgsConstructor;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Controller
@RequiredArgsConstructor
public class EmailController {

    private final EmailService emailService;

    @QueryMapping
    public List<Email> getEmailsBySender(@Argument  String sender) {
        return emailService.getEmailsBySender(sender);
    }

    @QueryMapping
    public List<Email> getEmailsBetweenUsers(@Argument String sender, @Argument String receiver, @Argument int limit, @Argument String sort) {
        return emailService.getRecentEmailsBetweenUsers(sender, receiver, limit, sort);
    }

    @QueryMapping
    public List<Email> getEmailsBySubject(@Argument String subject) {
        return emailService.getEmailsBySubject(subject);
    }

    @QueryMapping
    public List<EmailCountDTO> getEmailCountsBySender() {
        return emailService.getEmailCountsBySender();
    }

    @QueryMapping
    public List<Email> getEmailsByDateRange(@Argument LocalDate startDate, @Argument LocalDate endDate) {
        return emailService.getEmailsByDateRange(startDate, endDate);
    }

    @QueryMapping
    public List<Email> getEmailsWithAttachments() {
        return emailService.getEmailsWithAttachments();
    }

    @QueryMapping
    public List<Map<String, Object>> getTopRecipients(@Argument String sender, @Argument int limit) {
        return emailService.getTopRecipients(sender, limit);
    }

    @QueryMapping
    public List<Email> getEmailsByKeyword(@Argument String keyword) {
        return emailService.getEmailsByKeyword(keyword);
    }

    @QueryMapping
    public List<Email> getEmailsWithMultipleRecipients(@Argument int minRecipients) {
        return emailService.getEmailsWithMultipleRecipients(minRecipients);
    }


}
