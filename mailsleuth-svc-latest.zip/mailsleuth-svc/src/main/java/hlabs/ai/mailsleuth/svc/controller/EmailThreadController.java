package hlabs.ai.mailsleuth.svc.controller;

import hlabs.ai.mailsleuth.svc.models.EmailThread;
import hlabs.ai.mailsleuth.svc.service.EmailThreadService;
import lombok.RequiredArgsConstructor;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class EmailThreadController {

    private final EmailThreadService emailThreadService;

    @QueryMapping
    public List<EmailThread> getEmailThreads(@Argument String participant) {
        return emailThreadService.getEmailThreadsByParticipant(participant);
    }
}
