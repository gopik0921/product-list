package hlabs.ai.mailsleuth.svc.service;

import hlabs.ai.mailsleuth.svc.models.EmailThread;
import hlabs.ai.mailsleuth.svc.repositories.EmailThreadRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EmailThreadService {

    private final EmailThreadRepository emailThreadRepository;

    public List<EmailThread> getEmailThreadsByParticipant(String participant) {
        return emailThreadRepository.findThreadsByParticipant(participant);
    }
}
