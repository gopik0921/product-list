package hlabs.ai.mailsleuth.svc.repositories;

import hlabs.ai.mailsleuth.svc.models.EmailThread;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EmailThreadRepository extends JpaRepository<EmailThread, Long> {

    // Custom query to find email threads involving a specific participant
    @Query("SELECT et FROM EmailThread et JOIN et.emails e WHERE e.sender = :participant OR :participant MEMBER OF e.receiver")
    List<EmailThread> findThreadsByParticipant(@Param("participant") String participant);
}
