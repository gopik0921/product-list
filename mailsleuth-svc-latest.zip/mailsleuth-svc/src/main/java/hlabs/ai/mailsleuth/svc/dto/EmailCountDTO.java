package hlabs.ai.mailsleuth.svc.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class EmailCountDTO {
    private String sender;
    private Long emailCount;
}
