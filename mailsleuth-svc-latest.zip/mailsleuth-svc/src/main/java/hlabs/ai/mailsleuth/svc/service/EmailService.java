package hlabs.ai.mailsleuth.svc.service;

import hlabs.ai.mailsleuth.svc.dto.EmailCountDTO;
import hlabs.ai.mailsleuth.svc.models.Email;
import hlabs.ai.mailsleuth.svc.repositories.EmailRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class EmailService {

    private final EmailRepository emailRepository;

    public List<Email> getEmailsBySender(String sender) {
     return emailRepository.findBySender(sender);
    }

    public List<Email> getRecentEmailsBetweenUsers(String sender, String receiver, int limit, String sortDirection) {
        Pageable pageable = PageRequest.of(0, limit, Sort.by(Sort.Direction.fromString(sortDirection), "date"));
        return emailRepository.findEmailsBetweenUsers(sender, receiver, pageable);
    }

    public List<Email> getEmailsBySubject(String subject) {
        return emailRepository.findBySubject(subject);
    }

    public List<EmailCountDTO> getEmailCountsBySender() {
        return emailRepository.countEmailsBySender();
    }

    public List<Email> getEmailsByDateRange(LocalDate startDate, LocalDate endDate) {
        return emailRepository.findEmailsByDateRange(startDate, endDate);
    }

    public List<Email> getEmailsWithAttachments() {
        return emailRepository.findEmailsWithAttachments();
    }

    public List<Map<String, Object>> getTopRecipients(String sender, int limit) {
        List<Object[]> results = emailRepository.findTopRecipientsBySender(sender, limit);
        return results.stream()
                .map(row -> Map.of("receiver", row[0], "emailCount", row[1]))
                .limit(limit)
                .toList();
    }

    public List<Email> getEmailsByKeyword(String keyword) {
        return emailRepository.findEmailsByKeyword(keyword);
    }

    public List<Email> getEmailsWithMultipleRecipients(int minRecipients) {
        return emailRepository.findEmailsWithMultipleRecipients(minRecipients);
    }

}
