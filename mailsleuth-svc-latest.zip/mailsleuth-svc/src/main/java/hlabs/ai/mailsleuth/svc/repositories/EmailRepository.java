package hlabs.ai.mailsleuth.svc.repositories;

import hlabs.ai.mailsleuth.svc.dto.EmailCountDTO;
import hlabs.ai.mailsleuth.svc.models.Email;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface EmailRepository extends JpaRepository<Email, Long> {
    List<Email> findBySender(String sender);

    @Query("SELECT e FROM Email e WHERE (e.sender = :sender AND :receiver MEMBER OF e.receiver) " +
            "OR (e.sender = :receiver AND :sender MEMBER OF e.receiver)")
    List<Email> findEmailsBetweenUsers(
            @Param("sender") String sender,
            @Param("receiver") String receiver,
            Pageable pageable
    );

    List<Email> findBySubject(String subject);

    @Query("SELECT new hlabs.ai.mailsleuth.svc.dto.EmailCountDTO(e.sender, COUNT(e)) " +
            "FROM Email e GROUP BY e.sender")
    List<EmailCountDTO> countEmailsBySender();

    @Query("SELECT e FROM Email e WHERE e.date BETWEEN :startDate AND :endDate")
    List<Email> findEmailsByDateRange(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);

    @Query("SELECT e FROM Email e WHERE SIZE(e.attachment) > 0")
    List<Email> findEmailsWithAttachments();

    @Query("SELECT e.receiver, COUNT(e) AS emailCount " +
            "FROM Email e " +
            "WHERE e.sender = :sender " +
            "GROUP BY e.receiver " +
            "HAVING COUNT(e) > :limit " +
            "ORDER BY emailCount DESC")
    List<Object[]> findTopRecipientsBySender(@Param("sender") String sender, @Param("limit") int limit);

    @Query("SELECT e FROM Email e WHERE LOWER(e.subject) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
            "OR e.body LIKE CONCAT('%', :keyword, '%')")
    List<Email> findEmailsByKeyword(@Param("keyword") String keyword);

    @Query("SELECT e FROM Email e WHERE SIZE(e.receiver) > :minRecipients")
    List<Email> findEmailsWithMultipleRecipients(@Param("minRecipients") int minRecipients);

}
