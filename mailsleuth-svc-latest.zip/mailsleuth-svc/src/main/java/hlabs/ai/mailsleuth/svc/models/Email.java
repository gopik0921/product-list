package hlabs.ai.mailsleuth.svc.models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Data
@Builder
@Table(name = "emails")
@NoArgsConstructor
@AllArgsConstructor
public class Email {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String sender;
    private String subject;
    private String date;

    @ElementCollection
    @CollectionTable(name = "email_receivers", joinColumns = @JoinColumn(name = "email_id"))
    @Column(name = "receiver")
    private List<String> receiver;

    @OneToMany(mappedBy = "email", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Attachment> attachment;

    @Lob
    @Column(name = "body", columnDefinition = "TEXT")
    private String body;

    @ManyToOne
    @JoinColumn(name = "thread_id", referencedColumnName = "id")
    private EmailThread emailThread;

}
