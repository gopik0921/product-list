package hlabs.ai.mailsleuth.svc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MailsleuthSvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
