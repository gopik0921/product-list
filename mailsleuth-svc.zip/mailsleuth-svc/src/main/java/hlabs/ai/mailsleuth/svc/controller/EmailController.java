package hlabs.ai.mailsleuth.svc.controller;

import hlabs.ai.mailsleuth.svc.models.Email;
import hlabs.ai.mailsleuth.svc.service.EmailService;
import lombok.RequiredArgsConstructor;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class EmailController {

    private final EmailService emailService;

    @QueryMapping
    public List<Email> getEmails(@Argument  String sender, @Argument String subject) {
        return emailService.getEmails(sender, subject);
    }

    @QueryMapping
    public Email getEmailById(@Argument Long id) {
        return emailService.getEmailById(id);
    }

}
