package hlabs.ai.mailsleuth.svc.models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Data
@Builder
@Table(name = "emails")
@NoArgsConstructor
@AllArgsConstructor
public class Email {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String sender;
    private String subject;
    private String date;

    @ElementCollection
    private List<String> receiver;

    @Lob
    @Column(name = "body", columnDefinition = "TEXT")
    private String body;

}
