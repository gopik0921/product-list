package hlabs.ai.mailsleuth.svc.service;

import hlabs.ai.mailsleuth.svc.models.Email;
import hlabs.ai.mailsleuth.svc.repositories.EmailRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EmailService {

    private final EmailRepository emailRepository;

    // Query to get emails by sender or subject
    public List<Email> getEmails(String sender, String subject) {
        if (sender != null) {
            return emailRepository.findBySender(sender);
        } else if (subject != null) {
            return emailRepository.findBySubjectContaining(subject);
        } else {
            return emailRepository.findAll();
        }
    }

    // Query to get an email by ID
    public Email getEmailById(Long id) {
        return emailRepository.findById(id).orElse(null);
    }
}
