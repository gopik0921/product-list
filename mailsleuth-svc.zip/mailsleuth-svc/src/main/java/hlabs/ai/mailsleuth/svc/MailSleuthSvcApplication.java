package hlabs.ai.mailsleuth.svc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MailSleuthSvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(MailSleuthSvcApplication.class, args);
	}

}
