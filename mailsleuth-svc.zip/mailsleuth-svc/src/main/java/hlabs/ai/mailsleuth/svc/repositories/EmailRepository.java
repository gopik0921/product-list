package hlabs.ai.mailsleuth.svc.repositories;

import hlabs.ai.mailsleuth.svc.models.Email;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmailRepository extends JpaRepository<Email, Long> {
    List<Email> findBySender(String sender);
    List<Email> findByReceiverContaining(String receiver);
    List<Email> findBySubjectContaining(String subject);
}
