 INSERT INTO emails (sender, subject, date, body) VALUES
 ('eric.bass@enron.com', 'viewing pleasure', '2001-03-19 13:52:00-0800', 'body1');
 INSERT INTO emails (sender, subject, date, body) VALUES
 ('eric.bass@enron.com', 'rebook miran', '2001-03-19 13:52:00-0800', 'body2');
 INSERT INTO emails (sender, subject, date, body) VALUES
 ('eric.bass@enron.com', 'peril limb', '2001-03-19 13:52:00-0800', 'body3');
 INSERT INTO emails (sender, subject, date, body) VALUES
 ('eric.bass@enron.com', 'winning cultural', '2001-03-19 13:52:00-0800', 'body4');
 INSERT INTO emails (sender, subject, date, body) VALUES
 ('eric.bass@enron.com', 'good birthday weekend', '2001-03-19 13:52:00-0800', 'body5');

 INSERT INTO email_receiver (email_id, receiver) VALUES
 (1, 'chance.rabon@enron.com'),
 (2, 'lwbthemarine@bigplanet.com'),
 (3, 'daphneco64@bigplanet.com'),
 (4, 'benjamin.markey@enron.com'),
 (5, 'mballases@hotmail.com'),
 (5, 'shelleyzee@mail.utexas.edu'),
 (5, 'jason.bass2@compaq.com'),
 (5, 'brettlawler@hotmail.com'),
 (5, 'bryan.hull@enron.com'),
 (5, 'michael.walters@enron.com'),
 (5, 'oneal.winfree@enron.com'),
 (5, 'phillip.love@enron.com'),
 (5, 'david.baumbach@enron.com');